# 08 — WIREFRAME FRONTEND CÔNG KHAI — WEBSITE LT VIETNAM

**Phiên bản:** 1.1
**Mô hình:** Website doanh nghiệp B2B.
**Ngày:** 2026-07-21
**Nguồn sự thật cho:** bố cục & luồng trang công khai (khớp URL ở 02, API ở 06).
**Áp dụng:** ADR-001 (URL phẳng), 002 (slug/discontinued), 003 (form), 004 (locale), 007 (filter).

---

# PHẦN I — MỤC TIÊU UX

Ba nhiệm vụ: (1) Tìm sản phẩm phù hợp → (2) Hiểu năng lực LT Vietnam → (3) Gửi yêu cầu báo giá/hỗ trợ. Không mua hàng trực tuyến; khách không cần tài khoản/giỏ hàng/thanh toán.

Ba nhóm người dùng: đã biết model (dùng tìm kiếm/theo hãng/theo tiêu chuẩn) · biết nhu cầu chưa biết model (danh mục/ứng dụng/ngành/dịch vụ/tư vấn) · kiểm chứng năng lực (giới thiệu/dự án/khách hàng).

Nguyên tắc: chuyên nghiệp B2B, ít hiệu ứng, sản phẩm/dịch vụ là trung tâm, thông số dễ đọc, nút báo giá luôn dễ tìm, tốt trên mobile, không như website bán lẻ. **Không** hiển thị giá/giỏ hàng/tồn kho.

---

# PHẦN II — BỐ CỤC CHUNG

```text
TOP BAR: ĐT | Email | VP | VI/EN
HEADER: Logo | Menu chính | Tìm kiếm | [YÊU CẦU BÁO GIÁ]
MAIN
CTA LIÊN HỆ
FOOTER
```

## Header & Mega Menu (auto-generated — 02/06)
Menu chính: Trang chủ · Giới thiệu · Sản phẩm · Hãng & Đối tác · Dịch vụ · Dự án · Tin tức · Tài liệu · Liên hệ.
Mega menu "Sản phẩm" lấy **từ dữ liệu thật**: cột nhóm sản phẩm (danh mục `is_featured`), cột hãng (`is_featured`), cột tìm nhanh (tiêu chuẩn/ứng dụng cấu hình) + "Xem tất cả". Không liệt kê toàn bộ; không viết cứng.

Mobile: hamburger + drawer; nút "Yêu cầu báo giá" và VI/EN trong drawer.

---

# PHẦN III — TRANG CHỦ

Thứ tự section cố định (khớp 02/07): Hero · Lĩnh vực hoạt động · Danh mục nổi bật · Tìm theo nhu cầu (thanh tìm kiếm) · Sản phẩm nổi bật · Hãng & đối tác · Dịch vụ · Năng lực · Dự án mới · Tin tức · Khách hàng · CTA · Văn phòng.

Hero cần nói rõ LT Vietnam cung cấp gì + cho ai + hành động tiếp theo (ví dụ "Giải pháp thiết bị phân tích nhiên liệu…", `[XEM SẢN PHẨM] [NHẬN TƯ VẤN]`). Tránh khẩu hiệu chung chung.

Card sản phẩm: ảnh · hãng · tên · model · mô tả ngắn · tiêu chuẩn nổi bật · `[XEM CHI TIẾT]`. **Không** giá/mua/tồn kho/giỏ hàng.

Mobile: Header · Hero · Tìm kiếm · Danh mục · Sản phẩm · Dịch vụ · Hãng · Năng lực · Dự án · Tin tức · Khách hàng · CTA · Văn phòng · Footer.

---

# PHẦN IV — SẢN PHẨM

## Landing `/san-pham`
Cửa vào catalogue: thanh tìm kiếm · tìm theo nhóm (danh mục) · theo hãng · theo nhu cầu (tiêu chuẩn/ứng dụng/ngành) · sản phẩm nổi bật · CTA "không tìm thấy → gửi yêu cầu tư vấn".

## Danh sách & lọc `/san-pham/tat-ca`, `/san-pham/danh-muc/{slug}`, `/san-pham/hang/{slug}`
Filter sidebar (desktop) / drawer (mobile): Danh mục · Hãng · Thương hiệu con · Tiêu chuẩn · Ứng dụng.
Chip "Đang lọc: [PAC ×] [ASTM D86 ×] [Xóa tất cả]". **URL cập nhật theo filter** dùng slug key-lặp (ADR-007): `?brand=pac&standard=astm-d86` → khách sao chép/chia sẻ được. Kết quả AND. Sắp xếp: mặc định/mới cập nhật/A–Z/Z–A.
Empty state: "Không tìm thấy sản phẩm" + `[Xóa bộ lọc] [Gửi yêu cầu tư vấn]`.
`/san-pham/hang/{slug}` đặt `rel=canonical` về `/hang-doi-tac/{slug}` (02).

## Chi tiết `/san-pham/{product-slug}` (trang quan trọng nhất)
Đầu trang (không cần cuộn): ảnh + thumbnail · hãng · tên · model · mô tả ngắn · tiêu chuẩn nổi bật · `[YÊU CẦU BÁO GIÁ] [NHẬN TƯ VẤN]` · Tải catalogue.
Menu nội dung: Tổng quan · Tính năng · Ứng dụng · Tiêu chuẩn · Thông số · Tài liệu.
Khu vực: Tổng quan · Tính năng · Ứng dụng · Tiêu chuẩn (Compliance/Specification) · Thông số (bảng) · Tài liệu (tải) · Dịch vụ liên quan · Dự án thực tế · Sản phẩm liên quan · Form yêu cầu (tự điền sản phẩm).
Mobile: các phần dài dùng accordion; thanh CTA cố định `[GỌI TƯ VẤN] [YÊU CẦU BÁO GIÁ]`.

### Sản phẩm ngừng kinh doanh (ADR-002)
Nếu API trả cờ `discontinued`: hiển thị nhãn **"Sản phẩm đã ngừng kinh doanh"**, có thể ẩn nút báo giá trực tiếp, hiển thị **sản phẩm thay thế**. **Không** đổi/xóa URL. (Chỉ redirect khi DN duyệt.)

---

# PHẦN V — HÃNG, DỊCH VỤ, DỰ ÁN, TIN TỨC, TÀI LIỆU

## Hãng
Danh sách `/hang-doi-tac`. Chi tiết **canonical** `/hang-doi-tac/{brand-slug}`: ảnh bìa/logo/tên · giới thiệu · quốc gia/website · thương hiệu con (mỗi con là brand slug riêng, link `/hang-doi-tac/{child-slug}`) · nhóm sản phẩm · sản phẩm của hãng · dịch vụ liên quan · tài liệu & tin từ hãng · dự án · CTA. (Không dùng URL lồng cha/con.)

## Dịch vụ
Tổng `/dich-vu`: giới thiệu năng lực · nhóm dịch vụ · quy trình tiếp nhận · dự án tiêu biểu · CTA.
Chi tiết **`/dich-vu/{service-slug}`** (phẳng): tên/mô tả/ảnh · `[YÊU CẦU HỖ TRỢ]` · vấn đề khách gặp · phạm vi · quy trình · thiết bị/hãng · dự án liên quan · FAQ · form (tự điền dịch vụ).

## Dự án
Danh sách `/du-an` (lọc theo loại/sản phẩm/hãng/năm). Chi tiết **`/du-an/{project-slug}`**: banner · tên/loại · thông tin (khách hàng theo `customer_visibility` — backend quyết định) · phạm vi · triển khai · hình ảnh · kết quả · sản phẩm/dịch vụ liên quan · CTA. Nếu khách hàng đặt bảo mật: không hiển thị tên/logo.

## Tin tức
Tổng `/tin-tuc` + danh mục `/tin-tuc/danh-muc/{post-category-slug}`. Chi tiết **`/tin-tuc/{post-slug}`** (phẳng): danh mục/tiêu đề/ngày · ảnh · mục lục · nội dung · sản phẩm/bài liên quan.

## Tài liệu
Danh sách `/tai-lieu` (lọc loại/hãng/sản phẩm/ngôn ngữ) chỉ hiển thị tài liệu công khai; tải trực tiếp. Chi tiết `/tai-lieu/{document-slug}`.

---

# PHẦN VI — TÌM KIẾM, LIÊN HỆ, FORM YÊU CẦU

## Tìm kiếm `/tim-kiem?q=`
MVP: kết quả sản phẩm. **P1:** gộp nhóm (Sản phẩm/Dịch vụ/Bài viết/Dự án/Tài liệu). Không kết quả → thông báo + gợi ý + danh mục phổ biến + nút tư vấn.

## Liên hệ `/lien-he`
Form liên hệ (trái) + thông tin công ty/văn phòng (phải) + bản đồ. Form P0 **không có** file đính kèm (attachment → P1).

## Form yêu cầu dùng chung (modal) — ADR-003
```text
YÊU CẦU BÁO GIÁ                                   [X]
Sản phẩm: PAC OptiDist 2   (tự điền nếu mở từ trang SP)
Họ và tên * · Công ty * · Điện thoại * · Email *
Nội dung yêu cầu *
[ ] Tôi đồng ý với chính sách bảo mật.
[HỦY]                                   [GỬI YÊU CẦU]
```
- **P0 không có nút "Chọn file"** (attachment là P1).
- Tự điền: từ trang SP → `product_id`, `inquiry_type=quotation`, `source_url`; từ trang DV → `service_id`, `inquiry_type=technical_support`, `source_url`.
- **Idempotency (ADR-003):** frontend sinh `request_id`/`Idempotency-Key` duy nhất cho mỗi lần mở form; gửi kèm; khóa nút khi đang gửi để không gửi trùng.
- Trạng thái: "Đang gửi…" (khóa nút) → Thành công ("✓ Yêu cầu đã được gửi. LT Vietnam sẽ chủ động liên hệ.") → Lỗi ("Không thể gửi lúc này, vui lòng thử lại hoặc liên hệ ☎/✉"). Không lộ lỗi kỹ thuật.
- Backend trả `202` sau khi đã **lưu DB** (không phụ thuộc SMTP) — khách yên tâm không mất yêu cầu.

Vị trí mở form: Header · trang chủ · danh sách/chi tiết sản phẩm · dịch vụ · chi tiết hãng · dự án · liên hệ · trang không kết quả.

---

# PHẦN VII — ĐA NGÔN NGỮ (ADR-004)

- VI tại đường dẫn gốc, EN tại `/en`.
- Trang tiếng Anh của product/service/project/post/brand/page/document **chỉ hiển thị khi bản dịch EN `published`**. Nếu EN chưa publish: trả trạng thái đúng (trang không tồn tại ở EN / điều hướng về danh sách EN), **không trộn** nội dung VI vào trang EN.
- Fallback hạn chế cho dữ liệu ngắn (tên hãng, mã tiêu chuẩn, nhãn menu) — hiển thị nhất quán, ghi rõ.
- Chuyển ngôn ngữ giữ ngữ cảnh khi có bản dịch tương ứng; nếu trang hiện tại không có bản EN published, chuyển về trang danh sách tương ứng ở EN.

---

# PHẦN VIII — FOOTER & TRANG HỆ THỐNG

Footer: logo + giới thiệu ngắn · cột Công ty/Sản phẩm/Dịch vụ/Liên hệ · chính sách (bảo mật/điều khoản/cookie) · mạng xã hội · bản quyền. **Không** liên kết ngoài không liên quan, không nhồi từ khóa.

Trang hệ thống: 404 (tìm kiếm + về trang chủ + nhóm sản phẩm) · lỗi hệ thống (thân thiện, không stack trace) · yêu cầu thành công (`/yeu-cau-thanh-cong`, không lộ dữ liệu nhạy cảm).

---

# PHẦN IX — COMPONENT, TRẠNG THÁI, RESPONSIVE, SEO, HIỆU NĂNG, A11Y

- **Component:** PublicLayout, TopBar, Header, MegaMenu, MobileMenu, Breadcrumb, HeroBanner, SectionHeader, CategoryCard, ProductCard(+biến thể), BrandCard, ServiceCard, ProjectCard, PostCard, DocumentCard, CustomerLogo, SearchBox, FilterSidebar, MobileFilterDrawer, Pagination, ProductGallery, TechnicalSpecificationTable, DocumentDownload, InquiryModal, ContactForm, OfficeCard, CallToAction, Accordion, Tabs, EmptyState, ErrorState, LoadingSkeleton, Footer, CookieBanner.
- **Trạng thái:** skeleton loading; empty state kèm CTA tư vấn; error state có [Thử lại].
- **Responsive:** Mobile <768 · Tablet 768–1023 · Desktop ≥1024 · Large ≥1440. Menu→hamburger; lưới SP 3–4→1–2 cột; filter→drawer; bảng thông số cuộn ngang; CTA sản phẩm cố định mobile; form 1 cột.
- **SEO (khớp 02/06):** mỗi trang một `h1`, breadcrumb, canonical, hreflang VI↔EN (chỉ khi cả hai published), meta title/description, Open Graph, structured data (Organization/LocalBusiness, Product không giá, Article/NewsArticle, BreadcrumbList, FAQPage khi FAQ hiển thị).
- **Hiệu năng:** WebP/AVIF, responsive image, lazy load, không tải toàn bộ SP, hạn chế JS nặng, cache nội dung công khai, font tối ưu.
- **A11y:** dùng bàn phím, focus rõ, nút có nhãn, alt text, tương phản đủ, không chỉ dùng màu, form có label, lỗi mô tả bằng chữ, modal giữ focus, menu mobile đóng bằng bàn phím.

---

# PHẦN X — CÁC TRANG THEO GIAI ĐOẠN

**P0:** Trang chủ · Sản phẩm (landing/list/detail) · Hãng (list/detail) · Dịch vụ (tổng/detail) · Dự án (list/detail) · Tin tức (tổng/detail) · Tài liệu · Liên hệ · Form yêu cầu (không attachment) · Tìm kiếm sản phẩm · Chính sách bảo mật · 404.
**P1:** tìm kiếm toàn site · trang tiêu chuẩn/ứng dụng/ngành chi tiết · tài liệu tổng hợp nâng cao · FAQ · timeline lịch sử · landing page chiến dịch · **attachment trong form**.
**Chưa triển khai (Future):** đăng nhập/cổng khách hàng · giỏ hàng · thanh toán · theo dõi báo giá/ticket · thiết bị đã mua · kho tài liệu riêng. **Không** hiển thị các mục này như đã có sẵn.

---

# PHẦN XI — QUYẾT ĐỊNH CHỐT (Frontend 1.1)
1. URL chi tiết **phẳng** (ADR-001); hãng canonical `/hang-doi-tac/{slug}`; `/san-pham/hang/{slug}` chỉ lọc + canonical.
2. Nút báo giá nổi bật ở Header + đầu/cuối trang sản phẩm; mobile CTA cố định.
3. Form tự nhận sản phẩm/dịch vụ nguồn; **idempotency**; **không attachment** ở P0.
4. Backend lưu yêu cầu trước khi email → 202 (ADR-003); frontend hiển thị "đã tiếp nhận".
5. Sản phẩm ngừng KD giữ trang + nhãn + thay thế (ADR-002).
6. Mega menu auto-generated từ dữ liệu nổi bật.
7. Filter slug key-lặp, URL cập nhật theo filter (ADR-007).
8. Trang EN chưa publish trả trạng thái đúng, **không trộn ngôn ngữ** (ADR-004).
9. Không hiển thị chức năng P1/Future như đã triển khai.
10. Không giá/giỏ hàng/mua; component tái sử dụng; ưu tiên tốc độ/SEO/khả năng đọc.
