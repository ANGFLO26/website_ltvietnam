# 09 — ADR: CÁC QUYẾT ĐỊNH KIẾN TRÚC WEBSITE LT VIETNAM

**Phiên bản:** 1.0
**Ngày:** 2026-07-21
**Trạng thái bộ tài liệu:** Reviewed (chờ Approved)
**Vai trò tài liệu:** Nguồn sự thật cao nhất. Khi bất kỳ tài liệu nào mâu thuẫn với ADR, ADR thắng.

---

## Quy ước ADR

Mỗi ADR gồm: Mã · Tiêu đề · Trạng thái · Bối cảnh · Quyết định · Các phương án đã xem xét · Lý do lựa chọn · Hệ quả · Tài liệu bị ảnh hưởng · Ngày quyết định.

Trạng thái hợp lệ: `Proposed` · `Accepted` · `Superseded`.

Danh sách:

```text
ADR-001  Chiến lược URL công khai
ADR-002  Vòng đời và chính sách sử dụng slug
ADR-003  Lưu yêu cầu khách hàng và gửi email
ADR-004  Chiến lược xuất bản đa ngôn ngữ
ADR-005  Chính sách Media
ADR-006  Phạm vi MVP
ADR-007  Định dạng bộ lọc API công khai
ADR-008  Ngữ nghĩa PATCH và cập nhật quan hệ
ADR-009  Loại file upload trong MVP
```

---

# ADR-001 — Chiến lược URL công khai

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Sitemap phiên bản trước dùng URL chi tiết lồng nhau (`/dich-vu/{nhóm}/{dịch-vụ}`, `/tin-tuc/{danh-mục}/{bài}`, `/hang-doi-tac/{cha}/{con}`). Nhưng schema đặt `UNIQUE(locale, slug)` toàn module và API tra cứu bằng một slug phẳng. Hai dịch vụ "Bảo trì" thuộc hai nhóm khác nhau sẽ va chạm slug; API một slug không đủ dữ liệu để phân giải URL hai cấp; một hãng có tới hai URL chi tiết trùng nội dung.

## Quyết định
1. Trang **chi tiết** dùng URL **phẳng**, không đưa cấu trúc cha–con vào URL:
```text
/san-pham/{product-slug}
/dich-vu/{service-slug}
/du-an/{project-slug}
/tin-tuc/{post-slug}
/hang-doi-tac/{brand-slug}
/tai-lieu/{document-slug}
```
2. Trang **danh sách / phân loại** vẫn dùng URL theo nhóm:
```text
/san-pham/danh-muc/{category-slug}
/san-pham/tieu-chuan/{standard-slug}
/san-pham/ung-dung/{application-slug}
/tin-tuc/danh-muc/{post-category-slug}
```
3. **KHÔNG** dùng URL chi tiết lồng nhau: `/dich-vu/{parent}/{child}`, `/tin-tuc/{category}/{post}`, `/hang-doi-tac/{parent-brand}/{child-brand}`.
4. API công khai khớp URL phẳng:
```text
GET /api/v1/products/:slug
GET /api/v1/services/:slug
GET /api/v1/projects/:slug
GET /api/v1/posts/:slug
GET /api/v1/brands/:slug
GET /api/v1/documents/:slug
```
5. **Trang hãng canonical = `/hang-doi-tac/{brand-slug}`.** URL `/san-pham/hang/{brand-slug}` chỉ là **trang lọc sản phẩm theo hãng**, phải đặt `rel=canonical` trỏ về trang chi tiết hãng, không được là trang chi tiết hãng thứ hai.
6. Thương hiệu con là một `brand` độc lập với slug riêng, cũng dùng `/hang-doi-tac/{child-slug}`; quan hệ cha–con thể hiện qua `parent_id` và điều hướng nội trang, không qua URL.

## Các phương án đã xem xét
- **A. URL hai cấp + `UNIQUE(locale, parent_id, slug)` + API nhận đủ path.** Giữ URL "đẹp" theo phân cấp nhưng tăng phức tạp routing, API, redirect, và slug không ổn định khi đổi nhóm cha.
- **B. URL phẳng + slug duy nhất theo module (chọn).** Đơn giản, ổn định, khớp API và schema hiện có, slug không phụ thuộc cha.

## Lý do lựa chọn
Phương án B loại bỏ va chạm slug do trùng nhóm cha, giữ slug ổn định khi nội dung đổi danh mục, đơn giản hóa routing/redirect/sitemap, và khớp trực tiếp với `UNIQUE(locale, slug)` cùng API một-slug.

## Hệ quả
- Sitemap, API, frontend wireframe, mục SEO/redirect phải dùng URL phẳng.
- Cần `rel=canonical` cho trang lọc theo hãng.
- Đổi nhóm cha của dịch vụ/bài viết không đổi URL chi tiết ⇒ không phát sinh redirect.

## Tài liệu bị ảnh hưởng
01, 02, 06, 08, 10.

---

# ADR-002 — Vòng đời và chính sách sử dụng slug

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Vòng audit chỉ ra `UNIQUE(locale, slug)` không lọc `deleted_at` nên slug của nội dung xóa mềm vẫn chiếm namespace. Có đề xuất dùng partial unique index để tái sử dụng slug. Tuy nhiên tái sử dụng slug đã từng công khai gây nhầm lẫn SEO (một URL từng trỏ nội dung A nay trỏ nội dung B) và phá lịch sử liên kết.

## Quyết định
1. Giữ ràng buộc `UNIQUE(locale, slug)` **thường** trên từng bảng translation. **Không** dùng partial unique index để cho phép tái sử dụng slug của nội dung đã xóa mềm.
2. Slug **đã từng xuất bản không được tái sử dụng** cho nội dung khác.
3. Nội dung **xóa mềm vẫn giữ slug** (slug bị "khóa" vĩnh viễn ở trạng thái đã xóa mềm).
4. **Đổi slug** ⇒ hệ thống tự tạo redirect 301 từ slug cũ sang slug mới.
5. Nội dung **ngừng kinh doanh**: ưu tiên giữ trang, không xóa URL (xem ADR liên quan mục sản phẩm ngừng KD ở 01/06/08).
6. Chỉ **bản nháp CHƯA từng xuất bản** mới được **xóa vĩnh viễn** để giải phóng slug, theo quy trình có xác nhận.

## Quy trình xóa & khôi phục (ghi rõ trong 03, 05, 06)
```text
Bản nháp chưa từng publish   → được xóa vĩnh viễn (hard delete) → giải phóng slug
Nội dung đã từng publish      → chỉ xóa mềm (deleted_at) → giữ slug
Đổi slug nội dung đã publish  → tạo redirect 301 tự động (slug cũ → slug mới)
Khôi phục nội dung xóa mềm    → xóa deleted_at; slug cũ vẫn còn nên không va chạm
```

## Các phương án đã xem xét
- **A. Partial unique + đổi slug khi xóa mềm để tái dùng.** Cho tái sử dụng slug nhưng phá lịch sử SEO và tăng phức tạp.
- **B. UNIQUE thường + slug bảo lưu vĩnh viễn (chọn).** Bảo toàn lịch sử URL/SEO, đơn giản, redirect rõ ràng.

## Lý do lựa chọn
Bảo toàn giá trị SEO và tính minh bạch của URL quan trọng hơn khả năng tái dùng lại một chuỗi slug. Trường hợp tái nhập model cũ dùng redirect hoặc slug biến thể có kiểm soát.

## Hệ quả
- Không thể đặt slug trùng slug của một nội dung đã xóa mềm; nếu cần, dùng slug biến thể (vd thêm hậu tố) và redirect.
- PublishService/SlugService phải tự tạo redirect khi đổi slug.

## Tài liệu bị ảnh hưởng
03, 04, 05, 06, 08 (SEO), 10.

---

# ADR-003 — Lưu yêu cầu khách hàng và gửi email

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Thiết kế trước chỉ gửi email khi có form (`Form → SMTP → thành công hoặc mất`). Nếu SMTP lỗi, yêu cầu khách bị mất trong khi khách vẫn nhận thông báo thành công — rủi ro kinh doanh nghiêm trọng cho một website B2B sống bằng lead.

## Quyết định
1. **Mọi yêu cầu khách phải được lưu database trước khi gửi email.** Trả `202 Accepted` chỉ sau khi commit thành công, không phụ thuộc SMTP.
2. Luồng:
```text
Form → Validate → CAPTCHA + Rate limit
     → Transaction { INSERT inquiries; INSERT inquiry_outbox }
     → Commit → 202 Accepted
     → Worker nền gửi email → Retry khi thất bại
```
3. Thêm hai bảng: `inquiries`, `inquiry_outbox`.
4. **Không xây giao diện quản lý Inquiry trong Admin MVP.** Hai bảng chỉ để: không mất yêu cầu, retry email, idempotency, chuẩn bị mở rộng.

## `inquiries` — trường tối thiểu
```text
id, inquiry_type, full_name, company_name, phone, email, message,
product_id (nullable), service_id (nullable), source_url, locale,
privacy_consent_at, email_status, idempotency_key (UNIQUE),
created_at, expires_at (nullable, retention)
```

## `inquiry_outbox` — trường tối thiểu
```text
id, inquiry_id, channel, recipient, status, attempts,
next_attempt_at, last_error, sent_at
```

## Trạng thái gửi email (`inquiries.email_status` / `inquiry_outbox.status`)
```text
received        (mới lưu)
email_pending   (đang chờ worker gửi)
email_sent      (đã gửi thành công)
email_failed    (thất bại sau khi hết số lần thử)
```

## Data retention
`inquiries.expires_at` nullable. **Thời hạn lưu là quyết định doanh nghiệp** (xem 00_README Phần G; gợi ý mặc định 24 tháng). MVP **không** xây job purge tự động.

## Các phương án đã xem xét
- **A. Chỉ gửi email, không lưu.** Đơn giản nhưng mất lead khi SMTP lỗi — bị loại.
- **B. Outbox + inquiries + worker retry (chọn).** Không mất dữ liệu, idempotent, sẵn sàng mở rộng CRM/đa kênh.

## Hệ quả
- 01 đưa inquiry persistence vào P0.
- 06 thêm transaction + worker + idempotency; email gửi bất đồng bộ.
- Dashboard Admin có thể hiển thị số `email_failed` (widget trạng thái, không phải quản lý inquiry).

## Tài liệu bị ảnh hưởng
01, 03, 04, 05, 06, 07, 08, 10.

---

# ADR-004 — Chiến lược xuất bản đa ngôn ngữ

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
`status` trước đây chỉ nằm ở entity cha, không có publish theo từng ngôn ngữ. Không thể publish bản Việt trong khi bản Anh chưa xong; URL tiếng Anh sẽ 404 hoặc trộn ngôn ngữ. Scope yêu cầu tiếng Anh không bắt buộc hoàn thiện trong ngày ra mắt.

## Quyết định
1. Thêm `status` + `published_at` vào bảng translation của **7 entity nội dung chính**:
```text
product_translations
service_translations
project_translations
post_translations
brand_translations
page_translations
document_translations
```
2. Các bảng translation **taxonomy/config KHÔNG** có locale-status: `standard_translations, application_translations, industry_translations, product_category_translations, post_category_translations, office_translations, menu_item_translations, banner_translations, customer_translations`. Với nhóm này: **hiển thị khi có bản dịch**; cho phép **fallback hạn chế** cho dữ liệu ngắn (tên hãng, mã tiêu chuẩn, nhãn menu) và phải ghi rõ nơi áp dụng.
3. Quy tắc:
   - Tiếng Việt là ngôn ngữ mặc định, **bắt buộc `published`** trước khi entity được xuất bản.
   - Tiếng Anh **không bắt buộc** hoàn thiện lúc ra mắt; mỗi bản dịch xuất bản độc lập.
   - **Không auto-fallback** nội dung tiếng Việt cho URL tiếng Anh của product/service/project/post/brand/page/document (7 entity chính).
4. Điều kiện truy vấn công khai:
```text
entity.status = 'published'
AND entity.deleted_at IS NULL
AND translation.locale = requested_locale
AND translation.status = 'published'
```
5. API công khai chỉ trả translation `published`.

## `status` trên translation (7 entity chính)
```text
draft      (mặc định)
published
hidden
```
(Không cần `archived` ở tầng translation; vòng đời archive nằm ở entity cha.)

## Các phương án đã xem xét
- **A. Status chỉ ở entity cha.** Không tách được VI/EN — bị loại.
- **B. Locale-status cho MỌI translation (16 bảng).** Nhất quán tuyệt đối nhưng over-engineering cho taxonomy/config — bị loại.
- **C. Locale-status cho 7 entity nội dung chính, taxonomy dùng fallback (chọn).** Cân bằng giữa nhu cầu thật và độ phức tạp.

## Hệ quả
- 03/04/05 thêm `status`+`published_at` vào 7 bảng translation.
- 06 dùng điều kiện truy vấn công khai đầy đủ cả locale-status.
- 07 hiển thị badge trạng thái theo từng ngôn ngữ (VI ✓ / EN Thiếu / EN Nháp).
- 08 trang tiếng Anh chưa publish trả trạng thái đúng (404/empty theo quy tắc), không trộn ngôn ngữ.

## Tài liệu bị ảnh hưởng
01, 03, 04, 05, 06, 07, 08, 10.

---

# ADR-005 — Chính sách Media

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Schema trước không nhất quán: `products.featured_image_id ON DELETE SET NULL` (xóa media làm ảnh đại diện biến mất âm thầm) trong khi `product_media` dùng `RESTRICT`. Media xóa mềm vẫn được tham chiếu gây ảnh vỡ. SVG có nguy cơ XSS.

## Quyết định
1. **Không xóa (kể cả xóa mềm) media đang được sử dụng.** Luồng:
```text
Admin yêu cầu xóa media
 → MediaUsageService quét toàn bộ quan hệ tham chiếu
 → Nếu đang dùng: 409 MEDIA_IN_USE (kèm nơi dùng)
 → Nếu không dùng: soft delete (deleted_at)
 → Chờ khoảng giữ an toàn
 → Purge file vật lý
```
2. **Mọi FK media dùng chính sách nhất quán, ưu tiên `ON DELETE RESTRICT`.** Bỏ mọi `ON DELETE SET NULL` cho FK media (`featured_image_id`, `logo_id`, `cover_image_id`, `icon_id`, `social_image_id`, `image_id`, `mobile_image_id`, `file_id`, …). Không để `SET NULL` làm mất ảnh đại diện âm thầm.
3. Query công khai **không trả media đã xóa** (`media.deleted_at IS NULL`).
4. Media đang dùng phải hiển thị rõ **nơi sử dụng** trong Admin.
5. **MVP chỉ cho phép upload:** `JPG, JPEG, PNG, WebP, PDF`. **Không hỗ trợ SVG** trong MVP.

## Danh sách nơi tham chiếu media (MediaUsageService phải quét đủ)
```text
products.featured_image_id, product_translations.social_image_id, product_media.media_id,
brands.logo_id, brands.cover_image_id,
product_categories.featured_image_id, product_categories.icon_id,
applications.icon_id, industries.featured_image_id, industries.icon_id,
services.featured_image_id, projects.featured_image_id, project_media.media_id,
posts.featured_image_id, post_media.media_id, post_translations? (không),
pages.featured_image_id, page_translations.social_image_id,
customers.logo_id, offices.featured_image_id, menu_items.icon_id,
banners.image_id, banners.mobile_image_id,
documents.file_id,
brand_translations? (không), *_translations.social_image_id (product, page)
```

## Các phương án đã xem xét
- **A. SET NULL + không kiểm tra.** Mất ảnh âm thầm — bị loại.
- **B. RESTRICT nhất quán + app-check 409 (chọn).** An toàn, minh bạch.

## Hệ quả
- 05 đổi mọi FK media sang RESTRICT.
- 06 thêm MediaUsageService + 409 MEDIA_IN_USE + purge có trễ.
- 07 media picker hiển thị nơi dùng, chặn xóa khi đang dùng; upload chỉ 5 loại.
- Attachment của khách (P1) lưu tách, không vào Media công khai.

## Tài liệu bị ảnh hưởng
03, 05, 06, 07, 10.

---

# ADR-006 — Phạm vi MVP

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Cần khóa phạm vi để tránh trôi phạm vi và để các tài liệu không mô tả chức năng P1/Future như đã triển khai.

## Quyết định

### P0 — Bắt buộc
```text
Authentication Admin
Media cơ bản (JPG/JPEG/PNG/WebP/PDF)
Pages
Brands và sub-brands
Product Categories
Standards
Industries
Applications (giao diện phẳng)
Products
Services
Projects
Posts
Documents
Customers
Offices
Homepage cấu trúc section cố định (bật/tắt + chọn nổi bật)
Navigation đơn giản
Product Search (pg_trgm)
Product Filters (không facet count)
Inquiry persistence + email retry (inquiries + inquiry_outbox)
Redirect
SEO nền tảng (canonical, hreflang, sitemap.xml, robots.txt, structured data)
```

### P1 — Sau MVP
```text
Upload file trong form khách hàng (attachment)
Tìm kiếm toàn website
Facet count cho bộ lọc
Kéo thả thứ tự homepage section
Kéo thả menu tree
Dashboard cảnh báo thiếu nội dung
Bulk actions
Duplicate product
Scheduled publishing
Auto-save nâng cao
```

### Future
```text
CRM, Báo giá, Ticket kỹ thuật, Cổng khách hàng,
Bảo hành, Thiết bị theo serial, Ecommerce một phần, Phân quyền chi tiết
```

## Quy tắc
- Không đưa chức năng P1/Future vào yêu cầu bắt buộc của MVP.
- Không tài liệu nào được mô tả P1/Future như đã triển khai.
- Trường/bảng chuẩn bị tương lai được phép tồn tại trong schema nếu không cản trở, nhưng ẩn khỏi UI MVP.

## Tài liệu bị ảnh hưởng
Tất cả (01 là nguồn chi tiết), 10.

---

# ADR-007 — Định dạng bộ lọc API công khai

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Backend trước mô tả đồng thời hai kiểu multi-filter (`brand=pac,herzog` và `brand_id=id1&id2`) và tự ghi "nên thống nhất".

## Quyết định
1. **API công khai dùng slug**, nhiều giá trị dùng **query key lặp**:
```text
GET /api/v1/products?brand=pac&brand=herzog&standard=astm-d86&industry=oil-gas
```
2. **Không** hỗ trợ đồng thời kiểu comma (`brand=pac,herzog`) hay `brand_id`.
3. **Admin API** có thể dùng UUID.
4. `sort`/`order` chỉ nhận giá trị trong whitelist backend; không nhận tên cột SQL tùy ý.

## Hệ quả
06 và 08 dùng đúng một định dạng filter.

## Tài liệu bị ảnh hưởng
06, 08, 10.

---

# ADR-008 — Ngữ nghĩa PATCH và cập nhật quan hệ

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Cập nhật sản phẩm gồm nhiều mảng quan hệ (categories, standards, applications, industries, media, related products). Client gửi thiếu một mảng có thể vô tình xóa dữ liệu.

## Quyết định
```text
Nếu một trường mảng quan hệ XUẤT HIỆN trong PATCH
    → thay thế TOÀN BỘ tập quan hệ thuộc trường đó.
Nếu trường KHÔNG xuất hiện
    → giữ nguyên dữ liệu cũ.
```
Toàn bộ cập nhật nằm trong **một transaction**. Áp cho: categories, standards, applications, industries, media, related_products (và các mảng quan hệ tương tự ở services/projects/posts/documents).

## Hệ quả
06 ghi rõ hợp đồng PATCH; 07 form gửi đủ mảng khi có thay đổi nhóm đó.

## Tài liệu bị ảnh hưởng
06, 07, 10.

---

# ADR-009 — Loại file upload trong MVP

**Trạng thái:** Accepted
**Ngày:** 2026-07-21

## Bối cảnh
Cần chốt loại file để thiết kế validation và bảo mật upload; SVG có nguy cơ XSS.

## Quyết định
1. MVP chỉ cho phép: `JPG, JPEG, PNG, WebP, PDF`.
2. **Không SVG, không file thực thi.**
3. Kiểm tra **magic bytes/MIME thực tế** (không chỉ đuôi file), whitelist loại, giới hạn dung lượng, đổi tên an toàn, chống path traversal.
4. Attachment của khách (form yêu cầu) là **P1**; khi triển khai phải lưu tách khỏi Media công khai, URL token ngắn hạn.

## Hệ quả
05/06/07 dùng đúng whitelist; ADR-005 tham chiếu ADR-009.

## Tài liệu bị ảnh hưởng
03, 05, 06, 07, 10.

---

## Bảng tham chiếu ADR → Tài liệu

| ADR | 01 | 02 | 03 | 04 | 05 | 06 | 07 | 08 |
|-----|----|----|----|----|----|----|----|----|
| 001 URL |  | ● |  |  |  | ● |  | ● |
| 002 Slug |  | ● | ● | ● | ● | ● |  | ● |
| 003 Inquiry | ● |  | ● | ● | ● | ● | ● | ● |
| 004 Locale | ● |  | ● | ● | ● | ● | ● | ● |
| 005 Media |  |  | ● |  | ● | ● | ● |  |
| 006 MVP | ● | ● | ● | ● | ● | ● | ● | ● |
| 007 Filter |  |  |  |  |  | ● |  | ● |
| 008 PATCH |  |  |  |  |  | ● | ● |  |
| 009 Upload |  |  | ● |  | ● | ● | ● |  |
