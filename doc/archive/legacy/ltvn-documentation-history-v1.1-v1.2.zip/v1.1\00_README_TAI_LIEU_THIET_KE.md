# 00 — README BỘ TÀI LIỆU THIẾT KẾ WEBSITE LT VIETNAM

**Phiên bản bộ tài liệu:** 1.1
**Ngày cập nhật:** 2026-07-21
**Trạng thái:** `Reviewed` (chờ `Approved`)
**Sản phẩm:** Website doanh nghiệp B2B — Công ty TNHH Công nghệ LT Việt Nam.

---

## 1. Mục đích

Bộ tài liệu này là **nguồn sự thật duy nhất** để lập trình website LT Vietnam phiên bản đầu (MVP). Sau vòng audit, toàn bộ tài liệu đã được đồng bộ theo 9 ADR chính thức. Không tài liệu nào được mâu thuẫn với ADR.

## 2. Thứ tự đọc

```text
00_README                         (bạn đang đọc)
09_ADR_QUYET_DINH_KIEN_TRUC       ← đọc TRƯỚC TIÊN sau README (nền tảng mọi quyết định)
01_PHAM_VI_CHUC_NANG_VA_MVP
02_SITEMAP_VA_CAU_TRUC_DIEU_HUONG
03_CHUAN_HOA_MO_HINH_DU_LIEU
04_ERD_LOGIC_HE_THONG
05_DATABASE_SCHEMA_POSTGRESQL
06_KIEN_TRUC_BACKEND_VA_API
07_WIREFRAME_GIAO_DIEN_ADMIN
08_WIREFRAME_FRONTEND_CONG_KHAI
10_CHANGELOG_DONG_BO_TAI_LIEU     (nhật ký thay đổi so với bản cũ)
```

## 3. Nguồn sự thật cho từng vấn đề

| Vấn đề | Nguồn sự thật |
|---|---|
| Quyết định kiến trúc (thắng mọi mâu thuẫn) | **09_ADR** |
| Phạm vi, P0/P1/Future | 01 |
| URL công khai, điều hướng, sitemap | 02 |
| Mô hình dữ liệu logic, quy tắc trường | 03 |
| Quan hệ thực thể (ERD) | 04 |
| **Kiểu dữ liệu SQL, FK, index, constraint, migration** | **05** (thắng về kỹ thuật) |
| Endpoint, request/response, luồng nghiệp vụ | 06 |
| Giao diện & luồng Admin | 07 |
| Giao diện & luồng công khai | 08 |

Thứ tự ưu tiên khi mâu thuẫn: **ADR (09) > Phạm vi (01) > Schema (05) > ERD (04) > Chuẩn hóa dữ liệu (03) > API (06) > Admin (07) > Frontend (08)**.

## 4. Các quyết định lớn đã chốt (tóm tắt — chi tiết ở 09)

| ADR | Nội dung |
|---|---|
| 001 | URL chi tiết **phẳng** (`/san-pham/{slug}`…); hãng canonical `/hang-doi-tac/{slug}` |
| 002 | Slug đã publish **không tái dùng**; `UNIQUE(locale, slug)` thường; đổi slug tạo redirect 301 |
| 003 | **Lưu inquiry vào DB (`inquiries` + `inquiry_outbox`) trước khi gửi email**; worker retry; idempotency; không có UI quản lý inquiry ở MVP |
| 004 | Publish **theo từng ngôn ngữ** cho 7 entity chính (products/services/projects/posts/brands/pages/documents); EN không bắt buộc lúc ra mắt |
| 005 | Media FK **RESTRICT**; không xóa media đang dùng (409); **không SVG** |
| 006 | Khóa phạm vi P0/P1/Future |
| 007 | Bộ lọc public dùng **slug, key lặp** (`?brand=pac&brand=herzog`) |
| 008 | **PATCH**: mảng quan hệ có mặt → thay thế toàn bộ; vắng → giữ nguyên; trong transaction |
| 009 | Upload MVP chỉ **JPG/JPEG/PNG/WebP/PDF** |

Quyết định dữ liệu quan trọng: **bỏ** `products.primary_category_id` (dùng `product_category_links.is_primary`) · **bỏ** `service_documents` (dùng `document_services`) · **bỏ** `product_media.media_role='featured'` · giữ `products.brand_id NOT NULL` · applications phẳng trong Admin (DB giữ parent_id) · draft cho phép thiếu (chỉ `name`/`slug` bắt buộc).

## 5. Danh sách tài liệu (mới) & ánh xạ file cũ

| File chính thức | Thay cho (deprecated) |
|---|---|
| 00_README_TAI_LIEU_THIET_KE.md | — |
| 01_PHAM_VI_CHUC_NANG_VA_MVP.md | tai lieu pham vi chuc nang.md |
| 02_SITEMAP_VA_CAU_TRUC_DIEU_HUONG.md | sitemap.md |
| 03_CHUAN_HOA_MO_HINH_DU_LIEU.md | chuan hoa cau truc du lieu.md |
| 04_ERD_LOGIC_HE_THONG.md | ERD.md |
| 05_DATABASE_SCHEMA_POSTGRESQL.md | schema.md |
| 06_KIEN_TRUC_BACKEND_VA_API.md | thiet ke backend va danh sach API.md |
| 07_WIREFRAME_GIAO_DIEN_ADMIN.md | thiet ke wireframe va cau truc giao dien admin.md |
| 08_WIREFRAME_FRONTEND_CONG_KHAI.md | thiet ke wireframe frontend.md |
| 09_ADR_QUYET_DINH_KIEN_TRUC.md | — |
| 10_CHANGELOG_DONG_BO_TAI_LIEU.md | — |

Các file cũ (tên tiếng Việt có dấu cách: `schema.md`, `ERD.md`, `sitemap.md`, …) **đã được xóa** sau khi chuyển toàn bộ nội dung sang các file đánh số ở trên. Chỉ dùng bộ 00–10 để lập trình.

## 6. Quy tắc cập nhật (sửa dây chuyền)

Khi thay đổi một vấn đề, phải cập nhật **mọi tài liệu liên quan** và ghi vào 10_CHANGELOG:

```text
Đổi cấu trúc URL      → 02 + 06 + 08 + mục SEO + 09(ADR-001)
Đổi mô hình dữ liệu   → 03 + 04 + 05 + 06 + 07 (+ 09 nếu là quyết định)
Đổi luồng inquiry     → 01 + 03 + 04 + 05 + 06 + 08 (+ 09 ADR-003)
Đổi chính sách locale → 03 + 04 + 05 + 06 + 07 + 08 (+ 09 ADR-004)
Đổi chính sách media  → 03 + 05 + 06 + 07 (+ 09 ADR-005/009)
Đổi phạm vi           → 01 + tài liệu chứa chức năng đó (+ 09 ADR-006)
```

Không sửa một file rồi để file khác nói khác. Mọi thay đổi quyết định lớn phải tạo/ cập nhật một ADR.

## 7. Trạng thái phát hành

- `Draft` → đang soạn.
- `Reviewed` → đã đồng bộ, chờ doanh nghiệp xác nhận các điểm ở mục 8.
- `Approved` → doanh nghiệp đã xác nhận; sẵn sàng lập trình.

Bộ tài liệu hiện ở `Reviewed`. Xem `10_CHANGELOG` Phần cuối để biết các điểm còn chờ doanh nghiệp xác nhận.

## 8. Điểm còn chờ doanh nghiệp xác nhận (không chặn phần lớn việc code)

1. **Thời hạn lưu inquiry (`inquiries.expires_at`)** — gợi ý mặc định 24 tháng; DN chốt.
2. **Ai duyệt quyền công khai logo khách hàng/đối tác** (`is_public`, `customer_visibility`).
3. **Có gửi email xác nhận tự động cho khách** sau khi submit không (mặc định: không).
4. **Sản phẩm ngừng KD**: có sản phẩm thay thế mặc định/redirect trong trường hợp nào (mặc định giữ trang, không redirect).
5. **Domain gửi email + cấu hình SPF/DKIM/DMARC** (hạ tầng).
6. **Tiếng Anh** cần hoàn thiện đến đâu trước ngày ra mắt (mặc định: không bắt buộc).

Chi tiết mỗi điểm ở 10_CHANGELOG.
