# 06 — KIẾN TRÚC BACKEND VÀ API — WEBSITE LT VIETNAM

**Phiên bản:** 1.1
**Kiểu hệ thống:** Modular monolith · REST · prefix `/api/v1`
**Ngày:** 2026-07-21
**Nguồn sự thật cho:** ranh giới module, endpoint, hợp đồng request/response, luồng nghiệp vụ.
**Áp dụng:** ADR-001 (URL phẳng), 002 (slug), 003 (inquiry), 004 (locale), 005 (media), 007 (filter), 008 (PATCH), 009 (upload).

---

# PHẦN I — KIẾN TRÚC

Modular monolith, mỗi module: `Controller → DTO/Validator → Application Service → Repository → PostgreSQL`.
Module không truy cập repository của module khác; giao tiếp qua Service/QueryPort (vd `ProductQueryPort.getExistingProductIds`).

Module MVP:
```text
auth, users, media, settings,
pages, homepage, brands, product-categories, standards, applications, industries,
products, services, customers, projects, post-categories, posts, documents,
offices, navigation, redirects, search, inquiries, seo, health
```
`seo` mới: sinh `sitemap.xml` theo ngôn ngữ, `robots.txt`, hỗ trợ canonical/hreflang. `redirects` gồm middleware phục vụ 301/302.

Hạ tầng: PostgreSQL; File storage (adapter, local→S3/CDN sau); SMTP (adapter); worker nền (outbox). Redis **không bắt buộc** MVP (cache thời hạn ngắn + rate-limit in-process); khi scale ngang chuyển rate-limit/queue sang store dùng chung.

---

# PHẦN II — QUY ƯỚC API

## Phân nhóm
- Public: `/api/v1/*` — chỉ trả dữ liệu published, chưa xóa, đúng locale, được phép công khai.
- Admin: `/api/v1/admin/*` — yêu cầu đăng nhập; xem cả draft/hidden/archived/đã xóa mềm.
- Auth: `/api/v1/auth/*`.

## Ngôn ngữ & điều kiện công khai (ADR-004)
Ưu tiên `?locale` → `Accept-Language` → mặc định `vi`. Query công khai cho 7 entity chính:
```sql
WHERE entity.status='published' AND entity.deleted_at IS NULL
  AND translation.locale = :locale AND translation.status='published'
```
Taxonomy/config: hiển thị khi có bản dịch cho locale; fallback hạn chế (tên hãng/mã tiêu chuẩn/nhãn menu) ghi rõ tại endpoint áp dụng. **Không** auto-fallback VI cho URL EN của 7 entity chính.

## Phân trang / sắp xếp / lọc
`?page=1&page_size=20` (max 100). Response `{data, meta{page,page_size,total_items,total_pages}}`.
`sort`/`order` chỉ nhận whitelist backend.
**Bộ lọc (ADR-007):** dùng **slug**, key lặp cho nhiều giá trị:
```text
GET /api/v1/products?brand=pac&brand=herzog&standard=astm-d86&application=phan-tich-nhien-lieu&category=thiet-bi-chung-cat
```
Không hỗ trợ comma hay `brand_id` ở public API. Admin API dùng UUID.
Facet count là **P1** (public list MVP không trả facet).

---

# PHẦN III — XÁC THỰC ADMIN

JWT trong HttpOnly + Secure + SameSite=Strict cookie (không localStorage). Phiên 8h. **CSRF token** cho mọi request thay đổi trạng thái (POST/PATCH/DELETE). **CORS** chỉ cho origin cụ thể (`https://www.ltvietnam.com.vn`, `https://admin.ltvietnam.com.vn`) + `Allow-Credentials`. Password **Argon2id**. Rate-limit login 5/15'/IP; khóa sau N lần sai. Reset token có hạn ngắn, ký secret riêng, chứa `user_id`, vô hiệu khi `password_changed_at` đổi.

```text
POST /auth/login    POST /auth/logout    GET /auth/me
POST /auth/change-password   POST /auth/forgot-password   POST /auth/reset-password
```

---

# PHẦN IV — API CÔNG KHAI (URL phẳng — ADR-001)

```text
GET /home                              (HomepageQueryService tổng hợp; batch load tránh N+1; cache ngắn)

GET /pages/:slug

GET /brands                            ?type=&featured=&parent_id=
GET /brands/:slug                      (chi tiết hãng — canonical /hang-doi-tac/{slug})
GET /brands/:slug/children
GET /brands/:slug/products             (trang lọc sản phẩm theo hãng — canonical trỏ /brands/:slug)

GET /product-categories                GET /product-categories/tree
GET /product-categories/:slug          GET /product-categories/:slug/products

GET /standards                         GET /standards/:slug          GET /standards/:slug/products
GET /applications                      GET /applications/:slug       GET /applications/:slug/products
GET /industries                        GET /industries/:slug         GET /industries/:slug/products   GET /industries/:slug/services

GET /products                          (filter theo ADR-007)
GET /products/:slug                    (chi tiết; sản phẩm discontinued vẫn trả, kèm cờ discontinued + thay thế)

GET /services                          GET /services/tree            GET /services/:slug
GET /projects                          GET /projects/:slug
GET /posts                             GET /posts/:slug
GET /post-categories                   GET /post-categories/:slug/posts
GET /customers
GET /documents                         GET /documents/:slug          GET /documents/:id/download
GET /offices
GET /navigation/:location              (mega menu auto-generated)
GET /search                            (MVP: sản phẩm; P1: toàn site)
POST /inquiries                        (không đăng nhập; idempotency)
GET /health

# SEO (module seo)
GET /sitemap.xml                       GET /sitemap-:locale.xml       GET /robots.txt
```

Chi tiết sản phẩm trả: thông tin + brand + categories + specs + standards + applications + industries + media + documents + services/projects/related (đã lọc published + deleted_at). `customer_visibility` xử lý ở backend cho project.

---

# PHẦN V — API ADMIN

Mỗi module Admin hỗ trợ: `list, create, detail, update(PATCH), soft delete, restore, publish, hide, archive, reorder` (tùy module).
```text
/admin/pages   /admin/banners   /admin/homepage   /admin/brands   /admin/product-categories
/admin/standards   /admin/applications   /admin/industries   /admin/products   /admin/services
/admin/customers   /admin/projects   /admin/post-categories   /admin/posts   /admin/documents
/admin/media   /admin/offices   /admin/menus   /admin/settings   /admin/redirects
```
**Không có** `/admin/inquiries` trong MVP (ADR-003/006). **Không có** endpoint cho P1/Future (bulk, duplicate ngoài `products/:id/duplicate` là P1, scheduled publishing, facet, attachment).

## Publish (ví dụ sản phẩm)
```text
POST /admin/products/:id/publish
```
Kiểm (transaction): VI translation đủ điều kiện; brand/category chưa xóa; đúng 1 primary category; slug không trùng → set `products.status=published, published_at=NOW()` và `product_translations(vi).status=published`. Thiếu → 422 với mã lỗi (vd `PRODUCT_MISSING_PRIMARY_CATEGORY`). Publish EN riêng qua cập nhật translation EN.

## PATCH & quan hệ (ADR-008)
Trường mảng (categories, standards, applications, industries, media, related_products, …) **xuất hiện → thay thế toàn bộ tập**; **không xuất hiện → giữ nguyên**. Toàn bộ trong một transaction.
```text
BEGIN
  UPDATE products ...
  (nếu 'categories' có mặt) DELETE product_category_links WHERE product_id=?; INSERT ...
  (nếu 'standards' có mặt)  DELETE product_standards ...;                     INSERT ...
  (translations có mặt)     UPSERT product_translations ...
COMMIT   -- lỗi → ROLLBACK
```

## Slug & redirect (ADR-002)
Đổi slug nội dung đã publish → SlugService tự tạo `redirects(source=slug cũ, target=slug mới, 301)`; kiểm tránh chain/loop; slug đã publish không tái dùng; chỉ nháp chưa từng publish mới hard-delete.

---

# PHẦN VI — MEDIA (ADR-005/009)

```text
POST   /admin/media          (multipart; file,title,alt_text_vi,alt_text_en,caption_vi,caption_en,credit)
GET    /admin/media          ?type=&mime_type=&q=&page=
GET    /admin/media/:id
PATCH  /admin/media/:id
DELETE /admin/media/:id
```
Upload: kiểm **magic bytes/MIME thực**, whitelist `image/jpeg,image/png,image/webp,application/pdf` (**không SVG, không executable**), giới hạn dung lượng, đổi tên an toàn, chống path traversal, checksum chống trùng; tạo phiên bản (thumbnail/small/medium/large + WebP).
Xóa: `MediaUsageService` quét toàn bộ tham chiếu (danh sách ở ADR-005). Đang dùng → `409 MEDIA_IN_USE` kèm `details`. Không dùng → soft delete → giữ an toàn → purge file. Query công khai loại media `deleted_at IS NOT NULL`.

---

# PHẦN VII — INQUIRY (ADR-003)

```text
POST /api/v1/inquiries          (không đăng nhập)
Header: Idempotency-Key: <uuid>  (hoặc body.request_id)
```
Body:
```json
{ "inquiry_type":"quotation","full_name":"...","company_name":"...","phone":"...","email":"...",
  "message":"...","product_id":"uuid|null","service_id":"uuid|null","source_url":"/san-pham/...",
  "preferred_contact_method":"phone","province":"...","privacy_consent":true,"locale":"vi","captcha_token":"..." }
```
Luồng:
```text
Validate DTO → CAPTCHA → Rate limit (5/10'/IP)
→ Kiểm idempotency_key: nếu đã tồn tại → trả lại 202 của inquiry cũ (không tạo mới)
→ BEGIN
    INSERT inquiries (email_status='received', privacy_consent_at=NOW(), idempotency_key)
    INSERT inquiry_outbox (status='pending', recipient=settings.email.inquiry_recipient, next_attempt_at=NOW())
  COMMIT
→ 202 Accepted { request_id, message }
→ Worker nền: đọc outbox 'pending' đến hạn → gửi email → 'sent' | tăng attempts + đặt next_attempt_at (backoff) → sau N lần → 'failed'
→ đồng bộ inquiries.email_status
```
Response 202:
```json
{ "data": { "request_id": "uuid", "message": "Yêu cầu đã được tiếp nhận." } }
```

## Email (ADR liên quan 5.4)
- `From` = địa chỉ thuộc **domain LT Vietnam**; `Reply-To` = email khách. Không đặt email khách làm From.
- Sanitize mọi giá trị vào header/subject: bỏ CR/LF, giới hạn độ dài, dùng thư viện email chuẩn (không ghép raw header).
- Yêu cầu hạ tầng: SPF, DKIM, DMARC. Retry qua outbox. Theo dõi trạng thái outbox (dashboard hiển thị `email_failed`).
- Tiêu đề: `[YÊU CẦU BÁO GIÁ] PAC OptiDist 2 – Công ty ABC` (company đã sanitize).
- Kiến trúc mở rộng: `InquiryService` → `NotificationPort` → hiện tại `SMTPNotificationAdapter`; tương lai thêm `SaveInquiryAdapter (đã có)`, `CRMAdapter`, `ZaloAdapter`, `AdminNotificationAdapter` — form frontend không đổi.

## Attachment khách — **P1** (không có trong MVP)
Khi triển khai: `POST /inquiries/attachments` lưu tạm tách khỏi Media công khai, URL token ngắn hạn, whitelist PDF/JPG/PNG/DOCX, tự xóa sau 24–72h.

---

# PHẦN VIII — NAVIGATION & MEGA MENU

```text
GET /navigation/header    GET /navigation/mobile    GET /navigation/footer
```
`menu_items` quản mục cấp cao. **Mega menu sản phẩm auto-generated**: backend gộp danh mục `is_featured`, hãng `is_featured`, tiêu chuẩn/ứng dụng cấu hình. Admin không nhập tay toàn bộ. Backend kiểm menu: không vòng lặp, nội dung đích tồn tại & chưa xóa, URL ngoài hợp lệ.

Admin: `GET/POST/PATCH/DELETE /admin/menus`, `POST /admin/menus/:menu_id/items`, `PATCH/DELETE /admin/menu-items/:id`, `POST /admin/menus/:menu_id/reorder` (**kéo-thả cây → P1**, MVP dùng reorder cơ bản).

---

# PHẦN IX — HOMEPAGE, SEARCH, SETTINGS, REDIRECT, HEALTH

- **Homepage:** `GET /admin/homepage`, `PATCH /admin/homepage/sections/:section_type` (bật/tắt + chọn nội dung nổi bật). **`POST /admin/homepage/reorder` → P1** (kéo-thả thứ tự section). MVP thứ tự cố định.
- **Search:** MVP `GET /search?q=&type=product&locale=` dùng pg_trgm (tên/model/hãng/danh mục/tiêu chuẩn/mô tả). Toàn site (gộp service/project/post/document) → **P1**. API giữ nguyên khi đổi engine (Meilisearch/Elastic) sau.
- **Settings:** `GET /admin/settings`, `GET/PATCH /admin/settings/:group`. Không trả secret (`smtp_password: "********"`).
- **Redirect:** `GET/POST/PATCH/DELETE /admin/redirects`; middleware phục vụ trước router; kiểm source≠target, không loop/chain, source unique, source không trùng route đang phục vụ.
- **Health:** `GET /health` `{status, database, storage, email, timestamp}` — không lộ version/host/secret/SMTP.

---

# PHẦN X — RESPONSE, LỖI, VALIDATION

Response chuẩn `{data}` / `{data, meta}`. Lỗi:
```json
{ "error": { "code": "PRODUCT_NOT_FOUND", "message": "...", "details": null, "request_id": "uuid" } }
```
HTTP: 200/201/202/204/400/401/403/404/409/422/429/500.
Mã lỗi nghiệp vụ: `AUTH_INVALID_CREDENTIALS, AUTH_SESSION_EXPIRED, PRODUCT_NOT_FOUND, PRODUCT_SLUG_EXISTS, PRODUCT_MISSING_PRIMARY_CATEGORY, BRAND_PARENT_LOOP, CATEGORY_PARENT_LOOP, MEDIA_IN_USE, DOCUMENT_NOT_PUBLIC, INQUIRY_RATE_LIMITED, INQUIRY_DUPLICATE (idempotency), REDIRECT_LOOP, SLUG_RESERVED`.
Validation 3 lớp: frontend → DTO backend → DB constraint. Slug: chữ thường/không dấu/gạch ngang/không trùng theo module+locale/không dùng từ khóa hệ thống (`admin, api, login, search, media, health, en`).

Transaction bắt buộc: tạo/cập nhật/xuất bản sản phẩm, tạo dự án/bài viết kèm quan hệ, thay đổi cây danh mục, duplicate (P1), xóa mềm + cập nhật liên kết, thay đổi thứ tự menu, **tạo inquiry + outbox**.

---

# PHẦN XI — BẢO MẬT (đồng bộ 01/05/07)
HTTPS · CORS origin cụ thể + credentials · CSRF token · HttpOnly cookie · rate limit (login 5/15', inquiry 5/10', search 60/1', public 120/1') · input validation · HTML sanitization (whitelist tag/block, whitelist domain video, cấm iframe/script) · upload validation (ADR-009) · Argon2id · security headers · audit log tối thiểu (login, login fail, create, publish, delete, đổi settings). Không log PII/secret/JWT/cookie/nội dung file.

---

# PHẦN XII — SEO & MIGRATION (module seo + redirect)
- Sinh `sitemap.xml`/`sitemap-vi.xml`/`sitemap-en.xml` (chỉ URL published theo locale), `robots.txt`.
- Mỗi trang: canonical; hreflang VI↔EN ghép theo entity id (chỉ khi cả hai bản published); Open Graph; structured data (Organization/LocalBusiness, Product không giá, Article/NewsArticle, BreadcrumbList, FAQPage khi FAQ hiển thị).
- Redirect đổi slug (ADR-002); giữ URL sản phẩm ngừng KD (không redirect trừ khi DN duyệt); tránh chain/loop.
- Checklist crawl website cũ: `URL cũ | Loại | URL mới | Trạng thái migrate | 301 | Giữ/Sửa/Bỏ | Ảnh | PDF | Backlink`.

---

# PHẦN XIII — LOGGING & LUỒNG
Mỗi request có `X-Request-ID` (tự sinh nếu thiếu); log `{request_id, method, path, status, duration_ms, timestamp}`. Nhóm log: application/authentication/database/email/upload/security/performance.

Luồng đọc công khai: `Frontend → Public Controller → QueryService (locale + published + not deleted + filter) → Repository → PostgreSQL → Mapper → JSON`.
Luồng Admin ghi: `Admin FE → JWT+CSRF → Admin Controller → DTO → Service (nghiệp vụ + transaction + ghi DB + xóa cache + log) → Response`.

---

# PHẦN XIV — TRÌNH TỰ TRIỂN KHAI BACKEND
1. Nền tảng: cấu hình, DB connection, migration, error handler, logging, request-id, auth, users, settings, media.
2. Catalogue: brands, categories, standards, applications, industries, products, product search.
3. Nội dung: pages, homepage, services, customers, projects, posts, documents, offices, navigation.
4. Tương tác: **inquiries + outbox worker + idempotency + email (SPF/DKIM)** + CAPTCHA + rate limit.
5. Hoàn thiện: redirect middleware, seo (sitemap/robots/hreflang), cache, health, testing, backup, monitoring.

---

# PHẦN XV — QUYẾT ĐỊNH CHỐT (API 1.1)
1. Modular monolith, REST, `/api/v1`, tách public/admin.
2. URL & API **phẳng** cho trang chi tiết (ADR-001).
3. Locale publication ở backend (ADR-004); public chỉ trả translation published.
4. Inquiry: transaction lưu DB + outbox trước, 202, worker retry, idempotency (ADR-003).
5. Email: From domain công ty, Reply-To khách, sanitize header, SPF/DKIM/DMARC.
6. Filter slug key-lặp (ADR-007); facet count P1.
7. PATCH replace-tập-quan-hệ, transaction (ADR-008).
8. Media RESTRICT + 409 + MediaUsageService; không SVG (ADR-005/009).
9. Mega menu auto-generated; homepage thứ tự cố định (reorder P1).
10. Module seo sinh sitemap/robots/hreflang; redirect middleware.
11. Không endpoint cho P1/Future.
12. Search pg_trgm, đổi engine không đổi API.
