# 10 — CHANGELOG ĐỒNG BỘ TÀI LIỆU — WEBSITE LT VIETNAM

**Phiên bản:** 1.1
**Ngày:** 2026-07-21
**Nội dung:** mọi thay đổi khi đồng bộ bộ tài liệu từ bản cũ sang bản 1.1 theo 9 ADR.

---

## A. Ánh xạ tên file cũ → mới

| Tên cũ | Tên mới |
|---|---|
| tai lieu pham vi chuc nang.md | 01_PHAM_VI_CHUC_NANG_VA_MVP.md |
| sitemap.md | 02_SITEMAP_VA_CAU_TRUC_DIEU_HUONG.md |
| chuan hoa cau truc du lieu.md | 03_CHUAN_HOA_MO_HINH_DU_LIEU.md |
| ERD.md | 04_ERD_LOGIC_HE_THONG.md |
| schema.md | 05_DATABASE_SCHEMA_POSTGRESQL.md |
| thiet ke backend va danh sach API.md | 06_KIEN_TRUC_BACKEND_VA_API.md |
| thiet ke wireframe va cau truc giao dien admin.md | 07_WIREFRAME_GIAO_DIEN_ADMIN.md |
| thiet ke wireframe frontend.md | 08_WIREFRAME_FRONTEND_CONG_KHAI.md |
| (mới) | 00_README_TAI_LIEU_THIET_KE.md |
| (mới) | 09_ADR_QUYET_DINH_KIEN_TRUC.md |
| (mới) | 10_CHANGELOG_DONG_BO_TAI_LIEU.md |

File cũ ban đầu được giữ + đánh dấu DEPRECATED, sau đó **đã được xóa** theo yêu cầu (2026-07-21) vì nội dung đã chuyển đủ sang bộ 00–10.

---

## B. Bảng thay đổi chi tiết

| ID | File | Mục cũ | Thay đổi | Lý do | ADR |
|----|------|--------|----------|-------|-----|
| C01 | 03,04,05,06,07 | `products.primary_category_id NOT NULL` | **Xóa** cột; danh mục chính chỉ ở `product_category_links.is_primary` | Trùng nguồn danh mục chính, dễ lệch dữ liệu | 006 (data 4.1) |
| C02 | 03,04,05 | `service_documents` | **Xóa** bảng; chỉ giữ `document_services` | Hai bảng cùng một quan hệ | 006 (data 4.3) |
| C03 | 03,04,05,07 | `product_media.media_role='featured'` | **Bỏ** giá trị `featured`; ảnh đại diện ở `products.featured_image_id` | Tránh hai nơi lưu ảnh đại diện | 005 |
| C04 | 02,06,08 | URL chi tiết lồng nhau (`/dich-vu/{cha}/{con}`, `/tin-tuc/{cat}/{post}`, `/hang-doi-tac/{cha}/{con}`) | Chuyển sang **URL phẳng** (`/dich-vu/{slug}`, `/tin-tuc/{slug}`, `/hang-doi-tac/{slug}`) | Va chạm slug, API 1-slug không phân giải URL 2 cấp | 001 |
| C05 | 02,06,08 | Hãng có 2 URL chi tiết trùng | Chốt **canonical `/hang-doi-tac/{slug}`**; `/san-pham/hang/{slug}` là trang lọc, canonical trỏ về | Tránh trùng nội dung, phân tán SEO | 001 |
| C06 | 03,05,06 | `UNIQUE(locale, slug)` không rõ chính sách xóa | Chốt **slug không tái dùng**; UNIQUE thường; đổi slug tạo redirect; chỉ nháp chưa publish mới hard-delete | Bảo toàn lịch sử SEO/URL | 002 |
| C07 | 01,03,04,05,06,07,08 | Chỉ gửi email, không lưu | **Thêm `inquiries` + `inquiry_outbox`**; lưu trong transaction trước khi gửi; worker retry; 202 sau commit | Chống mất lead khi SMTP lỗi | 003 |
| C08 | 03,04,05,06,07,08 | `status` chỉ ở entity cha | **Thêm `status`+`published_at`** cho translation 7 entity chính (product/service/project/post/brand/page/document) | Publish VI/EN độc lập | 004 |
| C09 | 03,04,05,06,07 | `products.featured_image_id ON DELETE SET NULL` (không nhất quán) | Mọi FK media **RESTRICT**; MediaUsageService + 409; query công khai loại media đã xóa | Tránh mất ảnh âm thầm, ảnh vỡ | 005 |
| C10 | 01,03,05,06,07,08 | SVG cho phép; attachment khách P0 | **Không SVG** trong MVP; whitelist JPG/PNG/WebP/PDF; **attachment khách → P1** | Chống XSS SVG; thu gọn P0 | 005,009,006 |
| C11 | 03,05,07 | Cột mô tả `NOT NULL` chặn nháp | Chỉ `name`/`slug` NOT NULL; mô tả nullable; PublishService kiểm khi publish | Cho phép tạo nhanh + lưu nháp | 006 (data 4.7) |
| C12 | 03,05,06 | `documents.language` mơ hồ so với locale | Ghi rõ `language`=ngôn ngữ file vật lý; `document_translations.locale`=ngôn ngữ metadata | Tránh nhầm hai khái niệm | — |
| C13 | 05 | `product_specifications.group_name` / `settings.group` | Chốt `group_key` (spec), `group_name/setting_key` (settings) | Nhất quán tên cột + tránh từ khóa `group` | — |
| C14 | 03,05 | banner/menu `link_type` khác nhau | Đồng bộ enum (banner: product/product_category/brand/…; menu: page/product_category/brand/…); ghi chú `external_url`/`custom_url` | Nhất quán quan hệ đa hình | — |
| C15 | 06,08 | filter hai kiểu (comma + brand_id) | Chốt **slug, key lặp** (`?brand=pac&brand=herzog`) | Một định dạng nhất quán | 007 |
| C16 | 06,07 | PATCH không rõ ngữ nghĩa | Chốt: mảng có mặt → thay thế toàn bộ; vắng → giữ; transaction | Tránh mất dữ liệu quan hệ | 008 |
| C17 | 02 | Sitemap **lặp toàn bộ 2 lần** | **Xóa** phần lặp; viết lại gọn với URL phẳng | Lỗi chất lượng tài liệu | — |
| C18 | 06,08,07 | Mega menu nhập tay/mơ hồ | **Auto-generated** từ danh mục/hãng nổi bật + tiêu chuẩn/ứng dụng cấu hình | Tránh lệch catalogue, giảm nhập tay | — |
| C19 | 01,06,07,08 | Homepage kéo-thả thứ tự section (P0) | Thứ tự **cố định** + bật/tắt + chọn nổi bật; **reorder → P1** | Giảm phức tạp MVP | 006 |
| C20 | 01,07 | Applications quản lý cây (Admin) | DB giữ `parent_id`; **Admin hiển thị phẳng** | Ít giá trị, tránh over-engineering | 006 (data 4.5) |
| C21 | 06 | Chưa có SEO endpoint | Thêm module `seo`: `sitemap.xml`/`sitemap-{locale}.xml`/`robots.txt`, canonical, hreflang | SEO nền tảng P0 | 001,006 |
| C22 | 06 | Email chưa rõ chống spoof/injection | From=domain LT Vietnam, Reply-To=khách, sanitize CR/LF, SPF/DKIM/DMARC, retry outbox | Bảo mật email + deliverability | 003 |
| C23 | 01,06,08 | Sản phẩm ngừng KD chưa rõ | Giữ trang + nhãn + sản phẩm thay thế; không xóa URL (redirect chỉ khi DN duyệt) | Bảo toàn SEO | 002 |
| C24 | 03,05,06 | `brand_id` có thể trống với vật tư | Giữ **NOT NULL**; vật tư không hãng dùng brand chuẩn hóa `LT Vietnam`/`Generic`/`Other` | Không để sản phẩm mồ côi | 006 (data 4.4) |
| C25 | 06 | CSRF/CORS chưa đủ | Thêm CSRF token cho request thay đổi trạng thái; CORS origin cụ thể + credentials | Bảo mật Admin | — |
| C26 | 05,06 | Idempotency inquiry chưa có | `inquiries.idempotency_key UNIQUE` + `Idempotency-Key` header | Chống gửi trùng | 003 |
| C27 | 07 | Auto-save chưa rõ | Auto-save **chỉ vào nháp** (P1); bắt buộc cảnh báo rời trang chưa lưu | Tránh ghi đè bản published | 006 |
| C28 | 01,07 | bulk/duplicate/dashboard cảnh báo (P0) | Chuyển **P1** | Thu gọn MVP | 006 |

---

## C. Kết quả kiểm tra chéo (self cross-check)

| Hạng mục | Kết quả | Ghi chú |
|---|---|---|
| Phạm vi ↔ Sitemap | PASS | P0/P1/Future khớp; trang P1/Future không mô tả như đã có |
| Sitemap ↔ API | PASS | Mọi URL công khai có endpoint; không còn URL 2 cấp |
| Dữ liệu ↔ ERD | PASS | Bảng/quan hệ khớp; inquiries/outbox có ở cả hai |
| ERD ↔ Schema | PASS | Không còn primary_category_id/service_documents; FK/rule khớp |
| Schema ↔ API | PASS | Endpoint create/update có cột hỗ trợ; transaction bao phủ |
| API ↔ Admin | PASS | Trường form ↔ DTO; trường bắt buộc UI ↔ PublishService; draft không bị DB chặn |
| API ↔ Frontend | PASS | URL/filter/form/idempotency khớp |
| P0/P1/Future | PASS | Nhất quán toàn bộ tài liệu |
| URL/Slug/SEO | PASS | Phẳng, canonical hãng, không tái dùng slug, hreflang |
| Inquiry flow | PASS | Lưu DB trước khi email; outbox retry; idempotency |
| Media policy | PASS | RESTRICT + 409 + không SVG; không xóa khi đang dùng |
| Locale publication | PASS | 7 entity chính có status/published_at; taxonomy fallback |

---

## D. Blocker còn lại
Không còn blocker kỹ thuật Critical/High giữa các tài liệu. Các điểm ở Phần E là **quyết định doanh nghiệp**, không chặn phần lớn việc lập trình.

## E. Điểm cần doanh nghiệp xác nhận

| # | Câu hỏi | Ảnh hưởng | Phương án | Khuyến nghị |
|---|---|---|---|---|
| 1 | Thời hạn lưu inquiry (`expires_at`) | Retention/purge | (a) 24 tháng · (b) vô thời hạn · (c) khác | Ghi cột, mặc định 24 tháng, purge để P1 |
| 2 | Ai duyệt công khai logo KH/đối tác | Quy trình `is_public`/`customer_visibility` | (a) Admin tự quyết · (b) cần duyệt DN | Cần duyệt trước khi publish |
| 3 | Email xác nhận cho khách | Thêm nhánh NotificationPort | (a) không · (b) có | Mặc định không, dễ bật sau |
| 4 | Redirect sản phẩm ngừng KD | SEO | (a) giữ trang · (b) redirect thay thế | Giữ trang; redirect chỉ khi DN yêu cầu |
| 5 | Domain email + SPF/DKIM/DMARC | Deliverability | hạ tầng | Chốt domain gửi trước khi go-live |
| 6 | Mức hoàn thiện tiếng Anh khi ra mắt | Nội dung | (a) không bắt buộc · (b) bắt buộc | Không bắt buộc (ADR-004) |

## F. Kết luận
Xem `10` này cùng `00_README`. Bộ tài liệu đạt trạng thái **`READY WITH REMAINING BUSINESS DECISIONS`**: không còn mâu thuẫn Critical/High; schema đủ viết migration; API đủ viết controller/service; wireframe đủ dựng giao diện; phạm vi MVP đã khóa. Chỉ còn 6 quyết định doanh nghiệp (Phần E) cần chốt, phần lớn không chặn lập trình.
